package com.java;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Student s=new Student();
   s.setName("����");
   System.out.println(s.getName());
	
   
   Time t=new Time();
   t.setHour(25);
   System.out.println(t.getHour());
   
	
	}

}

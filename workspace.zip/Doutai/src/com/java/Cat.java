package com.java;

public class Cat extends Animal {

	public void showMe(){
		System.out.println("����è��");
	}
}

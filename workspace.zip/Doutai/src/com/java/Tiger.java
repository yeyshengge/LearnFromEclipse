package com.java;

public class Tiger extends Animal {

	public void showMe(){
	System.out.println("�����ϻ�");
	}
}

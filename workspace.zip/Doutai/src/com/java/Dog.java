package com.java;

public class Dog extends Animal {
	public void showMe(){
		System.out.println("����С��");
	}

}

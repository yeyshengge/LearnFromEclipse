package com.java;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Animal a = new Animal();
//a.showMe();

//Tiger t= new Tiger();
//t.showMe();

//Cat c= new Cat();
//c.showMe();

//Dog d = new Dog();
//d.showMe();
		
	Animal t=new Tiger();
	Animal d=new Dog();
	showMe(d);

}
	public static void showMe(Animal a){
		a.showMe();
		
		
	}
}
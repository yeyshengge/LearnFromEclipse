package Study;
public class Test3{
	public static void main(String[] args){
		for(int i=1;i<5;i++){
			for(int j=0;j<4-i;j++){
				System.out.print(" ");
			}for(int k=0;k<2*i-2;k++){
				if(k>0&&k<2*i-2){
					System.out.print("&");
				}else{
					System.out.print("#");
				}
			}
			System.out.println("*");
		}
	}
	
}